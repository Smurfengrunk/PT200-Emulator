﻿using PT200Emulator.Core;
using PT200Emulator.Models;
using PT200Emulator.Util;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Text;
using System.Windows;
using static PT200Emulator.Core.PT200State;
using static PT200Emulator.Util.Logger;

public class EscapeSequenceParser
{
    public event Action<byte[]> OutgoingDcs;

    private enum ParseState { Normal, Esc, Csi, Pt200Dollar, Pt200ZeroSymbol, Pt200ZeroHex, Dcs, DcsEsc, G0Select, EscDollar }

    private ParseState state = ParseState.Normal;
    private StringBuilder csiBuffer = new StringBuilder();
    private StringBuilder esc0Buffer = new StringBuilder();
    //private bool esc0HexMode = false;

    private List<byte> dcsBuffer = new List<byte>();
    //private bool dcsEscPending = false;

    private string g0Charset = "ASCII";
    private string g1Charset = "ASCII";
    private bool usingG1 = false;

    private readonly ScreenBuffer screenBuffer;
    private readonly Dictionary<string, Action> esc0Commands;
    private readonly Dictionary<string, Action<string>> esc0HexCommands;
    private readonly Dictionary<byte, char> g1Map;
    internal EmacsLayoutModel emacsLayout;
    public bool EmacsMode { get; internal set; }
    PT200State pstate = new PT200State();
    private bool inCommandMode = false;

    public event Action EmacsLayoutUpdated;
    private TcpTerminalClient tcpClient;
    private PT200State terminalState = new PT200State();

    public EscapeSequenceParser(ScreenBuffer buffer)
    {
        screenBuffer = buffer;
        esc0Commands = InitEsc0Commands();
        esc0HexCommands = InitEsc0HexCommands();
        g1Map = InitG1Map();
        var format = pstate.screenFormat;
        g0Charset = "ASCII";
        g1Charset = "ASCII";
        usingG1 = false;
        inCommandMode = true;   // blockera grafikläge tills vi vet att vi ska använda det
        state = ParseState.Normal;
        tcpClient = new TcpTerminalClient(this);
    }

    public event Action<byte[]> OutgoingRaw;

    private const int MaxDcsLength = 1024;
    private static readonly TimeSpan DcsTimeout = TimeSpan.FromMilliseconds(2000);

    private DateTime dcsStartTime = DateTime.Now;
    private DateTime csiStartTime = DateTime.Now;

    private const int MaxCsiLength = 256;
    private static readonly TimeSpan CsiTimeout = TimeSpan.FromMilliseconds(1000);
    private int graphicsSniffCount = 0;
    private int seqCharCount = 0;

    private void ChangeState(ParseState newState)
    {
        Logger.Log($"[STATE] {state} → {newState}", Logger.LogLevel.Debug);
        state = newState;
        seqCharCount = 0; // om du har failsafe-räknare
    }    

    private Queue<char> lastChars = new Queue<char>(3);

    private StringBuilder recentText = new StringBuilder();

    public void Feed(char ch)
    {
        // När CSI startar
        csiStartTime = DateTime.Now;

        // När DCS startar
        dcsStartTime = DateTime.Now;

        // Lägg till i recentText för att kunna matcha längre fraser
        recentText.Append(ch);
        if (recentText.Length > 100)
            recentText.Remove(0, recentText.Length - 100);

        if (!EmacsMode && recentText.ToString().Contains("EMACS") || recentText.ToString().Contains("Emacs Standard User Interface"))
        {
            EmacsMode = true;
            Logger.Log("[MODE] EMACS mode ON", Logger.LogLevel.Debug);
        }

        if (EmacsMode && (recentText.ToString().Contains("OK,")) || (recentText.ToString().Contains("ER!")))
        {
            EmacsMode = false;
            Logger.Log("[MODE] EMACS mode OFF", Logger.LogLevel.Debug);
            ChangeState(ParseState.Normal); // säkerställ att parsern är i rent läge
        }

        if (!EmacsMode && state != ParseState.Normal)
        {
            Logger.Log($"[FAILSAFE] Utanför EMACS men i state {state} – återställer", Logger.LogLevel.Debug);
            ChangeState(ParseState.Normal);
        }

        if (!EmacsMode)
        {
            Logger.Log($"[RAW OUTSIDE EMACS] Recent text: {recentText}", Logger.LogLevel.Debug);
        }
        else
        {
            Logger.Log($"[RAW INSIDE EMACS] Recent text: {recentText}", Logger.LogLevel.Debug);
        }

        // Avblockera kommandoläge om vi ser EMACS-start
        if (inCommandMode && recentText.ToString().Contains("Initializing EMACS"))
        {
            inCommandMode = false;
            Logger.Log("[Mode] Lämnar kommandoläge – EMACS startar (textmatch)", Logger.LogLevel.Debug);
        }

        switch (ch)
        {
            // Logga SO/SI
            case (char)0x0E: // SO – Shift Out (G1)
                {
                    if (inCommandMode)
                    {
                        Logger.Log("[Block] Ignorerar SO (Shift Out) i kommandoläge", Logger.LogLevel.Debug);
                        return;
                    }
                    usingG1 = true;
                    Logger.Log("[SO] Shift Out – växlar till G1", Logger.LogLevel.Debug);
                    break;
                }
            case (char)0x0F: // SI – Shift In (G0)
                {
                    usingG1 = false;
                    Logger.Log("[SI] Shift In – växlar till G0", Logger.LogLevel.Debug);
                    break;
                }

            // Ctrl-P (BREAK)
            case (char)0x10:
                {
                    Logger.Log("[PT200] BREAK (Ctrl-P) detected", Logger.LogLevel.Debug);
                    OutgoingRaw?.Invoke(new byte[] { 0x10 });
                    g0Charset = "ASCII";
                    g1Charset = "ASCII";
                    usingG1 = false;
                    inCommandMode = true;
                    Logger.Log("[Charset] Återställer till ASCII och går in i kommandoläge efter BREAK", Logger.LogLevel.Debug);
                    break;
                }
        }
        // Promptdetektor: håll senaste 3 tecken
        lastChars.Enqueue(ch);
        if (lastChars.Count > 3) lastChars.Dequeue();
        if (new string(lastChars.ToArray()) == "OK,")
        {
            g0Charset = "ASCII";
            g1Charset = "ASCII";
            usingG1 = false;
            inCommandMode = true;
            Logger.Log("[Charset] Återställer till ASCII och går in i kommandoläge vid OK,-prompt", Logger.LogLevel.Debug);
        }

        // State-maskin
        switch (state)
        {
            case ParseState.Normal:
                seqCharCount = 0;

                if (ch == 0x1B) // ESC
                {
                    ChangeState(ParseState.Esc);
                    Logger.Log("[STATE] Normal → Esc", Logger.LogLevel.Debug);
                }
                else if (ch == 0x18 || ch == 0x1A) // CAN eller SUB
                {
                    Logger.Log($"[CTRL] Avbrytsekvens mottagen: 0x{ch:X2}", Logger.LogLevel.Debug);
                    ChangeState(ParseState.Normal);
                }
                else
                {
                    HandleText(ch);
                }
                break;

            case ParseState.Esc:
                seqCharCount++;
                if (seqCharCount > 32) // eller annan rimlig gräns
                {
                    Logger.Log($"[FAILSAFE] Avbryter sekvens i state {state} efter {seqCharCount} tecken", Logger.LogLevel.Debug);
                    ChangeState(ParseState.Normal);
                    seqCharCount = 0;
                }
                Logger.Log($"[ESC RAW] ESC {ch} (0x{(int)ch:X2})", Logger.LogLevel.Debug);
                switch (ch)
                {
                    case '(':
                        ChangeState(ParseState.G0Select);
                        break;
                    case '`': // ESC `
                        Logger.Log("[ESC] Ladda ASCII i G0", Logger.LogLevel.Debug);
                        g0Charset = "ASCII";
                        ChangeState(ParseState.Normal);
                        break;
                    case '$':
                        Logger.Log("[ESC] Dollar-sekvens start", Logger.LogLevel.Debug);
                        ChangeState(ParseState.Normal);
                        break;
                    case '[':
                        csiBuffer.Clear();
                        csiStartTime = DateTime.Now; // starttid för CSI
                        Logger.Log($"[CSI] Startar vid {csiStartTime:HH:mm:ss.fff}", Logger.LogLevel.Debug);
                        Logger.Log($"[CSI] RAW[{csiBuffer}{ch}", Logger.LogLevel.Debug);
                        ChangeState(ParseState.Csi);
                        break;
                    case 'P':
                        Logger.Log("[ESC] Startar DCS", Logger.LogLevel.Debug);
                        dcsBuffer.Clear();
                        dcsStartTime = DateTime.Now; // starttid för DCS
                        Logger.Log($"[DCS] Startar vid {dcsStartTime:HH:mm:ss.fff}", Logger.LogLevel.Debug);
                        ChangeState(ParseState.Dcs);
                        break;
                    case 'b':
                        g0Charset = "ASCII";
                        Logger.Log("[Charset] G0 satt till ASCII via ESC b", Logger.LogLevel.Debug);
                        ChangeState(ParseState.Normal);
                        break;
                    case '0':
                        ChangeState(ParseState.Pt200ZeroSymbol);
                        esc0Buffer.Clear();
                        break;
                    case 'c': // Full reset
                        Logger.Log("[ESC] Full reset mottagen", Logger.LogLevel.Debug);
                        ResetParserState();
                        ResetScreenState(); // om du har en metod för att nollställa skärmen
                        ChangeState(ParseState.Normal);
                        break;
                    default:
                        Logger.Log($"[ESC] Okänd sekvens: 0x{(int)ch:X2}", Logger.LogLevel.Debug);
                        ChangeState(ParseState.Normal);
                        break;
                }
                break;

            case ParseState.G0Select:
                seqCharCount++;
                if (seqCharCount > 32) // eller annan rimlig gräns
                {
                    Logger.Log($"[FAILSAFE] Avbryter sekvens i state {state} efter {seqCharCount} tecken", Logger.LogLevel.Debug);
                    ChangeState(ParseState.Normal);
                    seqCharCount = 0;
                }
                if (ch == 'B')
                {
                    g0Charset = "ASCII";
                    Logger.Log("[Charset] G0 satt till ASCII via ESC (B", Logger.LogLevel.Debug);
                }
                else if (ch == '0')
                {
                    if (inCommandMode)
                    {
                        Logger.Log("[Block] Ignorerar ESC (0 i kommandoläge", Logger.LogLevel.Debug);
                    }
                    else
                    {
                        g0Charset = "Graphics";
                        Logger.Log("[Charset] G0 satt till Graphics via ESC (0", Logger.LogLevel.Debug);
                    }
                }
                else
                {
                    Logger.Log($"[Charset] Okänd G0‑charset: 0x{(int)ch:X2}", Logger.LogLevel.Debug);
                }
                ChangeState(ParseState.Normal);
                break;

            case ParseState.Pt200Dollar:
                seqCharCount++;
                if (seqCharCount > 32) // eller annan rimlig gräns
                {
                    Logger.Log($"[FAILSAFE] Avbryter sekvens i state {state} efter {seqCharCount} tecken", Logger.LogLevel.Debug);
                    ChangeState(ParseState.Normal);
                    seqCharCount = 0;
                }
                if (ch == 'G')
                {
                    if (inCommandMode)
                    {
                        Logger.Log("[Mode] Lämnar kommandoläge – ESC $G från EMACS", Logger.LogLevel.Debug);
                        inCommandMode = false;
                    }
                    g1Charset = "Graphics";
                    usingG1 = true;
                    Logger.Log("[Charset] G1 satt till Graphics via ESC $G", Logger.LogLevel.Debug);
                }
                else if (ch == 'B')
                {
                    g0Charset = "ASCII";
                    Logger.Log("[Charset] G0 satt till ASCII via ESC $B", Logger.LogLevel.Debug);
                }
                else
                {
                    Logger.Log($"[Charset] Okänd $‑sekvens: 0x{(int)ch:X2}", Logger.LogLevel.Debug);
                }
                ChangeState(ParseState.Normal);
                break;

            case ParseState.Pt200ZeroSymbol:
                seqCharCount++;
                if (seqCharCount > 32) // eller annan rimlig gräns
                {
                    Logger.Log($"[FAILSAFE] Avbryter sekvens i state {state} efter {seqCharCount} tecken", Logger.LogLevel.Debug);
                    ChangeState(ParseState.Normal);
                    seqCharCount = 0;
                }
                esc0Buffer.Append((char)ch);
                if (esc0Buffer.Length == 2 && esc0Buffer[1] == '!')
                {
                    if (esc0Commands.TryGetValue(esc0Buffer.ToString(), out var action))
                        action();
                    else
                        Logger.Log($"[ESC0] Okänt kommando: {esc0Buffer}", Logger.LogLevel.Debug);

                    ChangeState(ParseState.Normal);
                }
                else if (esc0Buffer.Length == 2 && esc0Buffer[1] != '!')
                {
                    // Om det ser ut som hex, byt state
                    ChangeState(ParseState.Pt200ZeroHex);
                }
                break;

            case ParseState.Pt200ZeroHex:
                seqCharCount++;
                if (seqCharCount > 32) // eller annan rimlig gräns
                {
                    Logger.Log($"[FAILSAFE] Avbryter sekvens i state {state} efter {seqCharCount} tecken", Logger.LogLevel.Debug);
                    ChangeState(ParseState.Normal);
                    seqCharCount = 0;
                }
                esc0Buffer.Append((char)ch);
                if (esc0Buffer.Length == 3 && esc0Buffer[2] == '*')
                {
                    var hex = $"{(byte)esc0Buffer[0]:X2}{(byte)esc0Buffer[1]:X2}";
                    if (esc0HexCommands.TryGetValue(hex, out var hexAction))
                        hexAction(hex);
                    else
                        Logger.Log($"[ESC0] Okänt hexkommando: {hex}", Logger.LogLevel.Debug);

                    ChangeState(ParseState.Normal);
                }
                break;

            case ParseState.EscDollar:
                if (ch == 'O')
                {
                    Logger.Log("[ESC] Ladda PT200-grafik i G1", Logger.LogLevel.Debug);
                    g1Charset = "Graphics";
                }
                else
                {
                    Logger.Log($"[ESC] Okänd $‑sekvens: {ch}", Logger.LogLevel.Debug);
                }
                ChangeState(ParseState.Normal);
                break;
            case ParseState.Csi:
                seqCharCount++;
                if (seqCharCount > 32) // eller annan rimlig gräns
                {
                    Logger.Log($"[FAILSAFE] Avbryter sekvens i state {state} efter {seqCharCount} tecken", Logger.LogLevel.Debug);
                    ChangeState(ParseState.Normal);
                    seqCharCount = 0;
                }
                HandleEscSequence(csiBuffer.ToString());

                if (char.IsLetter(ch))
                {
                    csiBuffer.Append(ch);
                    string seq = csiBuffer.ToString();

                    // Kolla om det är en kursorrörelse
                    if ("ABCDHf".Contains(ch))
                    {
                        Logger.Log($"[CSI] Ignorerar kursorrörelse: ESC[{seq}", Logger.LogLevel.Debug);
                        // Gör inget – hoppa över positioneringskommandot
                    }
                    else if (seq == "c") // Primary DA
                    {
                        // PT200 svar – exempel: ESC[?62;1;2c
                        var response = "\x1B[?62;1;2c";
                        _ = tcpClient.SendAsync(response); // starta asynkront, vänta inte
                        Logger.Log($"[DA] Skickade Primary DA-svar: {response}", Logger.LogLevel.Debug);
                        return;
                    }
                    else if (seq == ">0c")
                    {
                        var reply = "\x1B[>1;10;0c"; // Exempelvärden
                        _ = tcpClient.SendAsync(reply);
                        Logger.Log($"[DA] Skickade Secondary DA-svar: {reply}", Logger.LogLevel.Debug);
                    }
                    else if (ch == 'Z')
                    {
                        var reply = "\x1B/Z"; // PT200 kan svara med sin ID-sträng här
                        _ = tcpClient.SendAsync(reply);
                        Logger.Log($"[ID] Skickade identifikationssvar: {reply}", Logger.LogLevel.Debug);
                    }
                    else
                    {
                        HandleCSI(seq); // annan CSI-hantering om du vill
                    }

                    ChangeState(ParseState.Normal);
                }
                else
                {
                    csiBuffer.Append(ch);
                }
                break;

            case ParseState.Dcs:
                seqCharCount++;
                if (seqCharCount > 32) // eller annan rimlig gräns
                {
                    Logger.Log($"[FAILSAFE] Avbryter sekvens i state {state} efter {seqCharCount} tecken", Logger.LogLevel.Debug);
                    ChangeState(ParseState.Normal);
                    seqCharCount = 0;
                }
                Logger.Log($"[DCS RAW] ESC P ...", Logger.LogLevel.Debug);
                HandleEscSequence(Encoding.ASCII.GetString(dcsBuffer.ToArray()));
                // Första gången vi går in i DCS-läget
                if (dcsBuffer.Count == 0)
                {
                    dcsStartTime = DateTime.Now;
                    Logger.Log($"[DCS] Startar DCS-sekvens vid {dcsStartTime:HH:mm:ss.fff}", Logger.LogLevel.Debug);
                }
                if (DateTime.Now - dcsStartTime > TimeSpan.FromSeconds(2))
                {
                    Logger.Log("[DCS] Timeout – avbryter DCS-sekvens", Logger.LogLevel.Debug);
                    ChangeState(ParseState.Normal);
                    return;
                }

                if (ch == 0x1B) // ESC avslutar DCS
                {
                    ChangeState(ParseState.DcsEsc);
                }
                else
                {
                    dcsBuffer.Add((byte)ch); // eller .Append(ch) om StringBuilder
                }
                break;

            case ParseState.DcsEsc:
                seqCharCount++;
                if (seqCharCount > 32) // eller annan rimlig gräns
                {
                    Logger.Log($"[FAILSAFE] Avbryter sekvens i state {state} efter {seqCharCount} tecken", Logger.LogLevel.Debug);
                    ChangeState(ParseState.Normal);
                    seqCharCount = 0;
                }
                if (ch == '\\')
                {
                    var duration = DateTime.Now - dcsStartTime;
                    Logger.Log($"[DCS] Avslutad efter {duration.TotalMilliseconds} ms", Logger.LogLevel.Debug);
                    var data = dcsBuffer.ToArray();
                    OutgoingDcs?.Invoke(data); // <-- trigga eventet
                    var bytes = dcsBuffer.ToArray();
                    Logger.Log($"[DCS] Mottog DCS-sekvens (ASCII): {Encoding.ASCII.GetString(bytes)}", Logger.LogLevel.Debug);
                    Logger.Log($"[DCS] Mottog DCS-sekvens (HEX): {BitConverter.ToString(bytes)}", Logger.LogLevel.Debug);
                    HandleDcs(bytes);
                    HandleEscSequence(dcsBuffer.ToString());
                    dcsBuffer.Clear();
                    ChangeState(ParseState.Normal);
                }
                else
                {
                    dcsBuffer.Add((byte)'\x1B');
                    dcsBuffer.Add((byte)ch);
                    ChangeState(ParseState.Dcs);
                }
                break;
        }
        _ = dcsStartTime;
        _ = csiStartTime;
    }

    private void HandleDcs(byte[] data)
    {
        if (data.Length == 0)
        {
            Logger.Log("[DCS] Tom DCS – statusförfrågan", Logger.LogLevel.Debug);
            terminalState.DumpDcsDebug();

            var reply = terminalState.GenerateDCSResponse();
            _ = tcpClient.SendAsync(reply);
            Logger.Log($"[DCS] Skickade status: {BitConverter.ToString(Encoding.ASCII.GetBytes(reply))}", Logger.LogLevel.Debug);

            // Skicka “ready-signal” direkt efter status
            _ = tcpClient.SendAsync("\x11"); // XON som vissa hostar tolkar som “redo”
            //_ = tcpClient.SendAsync("\r");  // alternativt CR
            //_ = tcpClient.SendAsync("\x11"); // ENQ som vissa hostar tolkar som “redo”

            return;
        }

        Logger.Log($"[DCS] Mottog DCS-sekvens (ASCII): {Encoding.ASCII.GetString(data)}", Logger.LogLevel.Debug);
        Logger.Log($"[DCS] Mottog DCS-sekvens (HEX): {BitConverter.ToString(data)}", Logger.LogLevel.Debug);
    }

    private void HandleEscSequence(string seq)
    {
        //Logger.Log($"[ESC RAW] {seq}", Logger.LogLevel.Debug);


        // Primary DA: ESC [ c
        if (seq == "[c")
        {
            var reply = "\x1B[?62;1;2c"; // PT200 ID
            _ = tcpClient.SendAsync(reply);
            Logger.Log($"[DA] Skickade Primary DA-svar: {reply}", Logger.LogLevel.Debug);
        }

        // Secondary DA: ESC [ > c
        else if (seq == "[>c" || seq.StartsWith("[>"))
        {
            var reply = "\x1B[>1;10;0c"; // exempelvärden
            _ = tcpClient.SendAsync(reply);
            Logger.Log($"[DA] Skickade Secondary DA-svar: {reply}", Logger.LogLevel.Debug);
        }

        // Identify Terminal: ESC Z
        else if (seq == "Z")
        {
            var reply = "\x1B/Z";
            _ = tcpClient.SendAsync(reply);
            Logger.Log($"[ID] Skickade identifikationssvar: {reply}", Logger.LogLevel.Debug);
        }

        // PT200-specifika sekvenser som ESC ` och ESC $ O
        else if (seq == "`" || seq == "$O")
        {
            Logger.Log($"[ESC] Ignorerar PT200-specifik sekvens: ESC {seq}", Logger.LogLevel.Debug);
        }
    }
    private void AdvanceLine()
    {
        screenBuffer.CursorRow++;
        if (screenBuffer.CursorRow >= screenBuffer.Rows)
        {
            screenBuffer.ScrollUp();
            screenBuffer.CursorRow = screenBuffer.Rows - 1;
        }
    }

    private void HandleText(char ch)
    {
        char outChar = ch;

        // Om vi är i grafikläge, logga alltid
        if (g0Charset == "Graphics" || g1Charset == "Graphics")
        {
            string bank = usingG1 ? "G1" : "G0";
            Logger.Log($"[Graphics Debug] Bank={bank}, Byte=0x{(int)ch:X2} '{(char.IsControl(ch) ? '.' : ch)}'", Logger.LogLevel.Debug);
        }

        // Sniffa första 20 tecken efter force‑G1
        if (graphicsSniffCount > 0)
        {
            Logger.Log($"[Graphics Sniff] Byte=0x{(int)ch:X2} '{(char.IsControl(ch) ? '.' : ch)}'", Logger.LogLevel.Debug);
            graphicsSniffCount--;
        }

        // G1-grafik
        if (usingG1 && g1Charset == "Graphics" && g1Map.TryGetValue((byte)ch, out var mapped))
        {
            Logger.Log($"[G1 Graphics] Mappade 0x{(int)ch:X2} → '{mapped}'", Logger.LogLevel.Debug);
            outChar = mapped;
        }
        // G0-grafik
        else if (!usingG1 && g0Charset == "Graphics" && g1Map.TryGetValue((byte)ch, out var mappedG0))
        {
            Logger.Log($"[G0 Graphics] Mappade 0x{(int)ch:X2} → '{mappedG0}'", Logger.LogLevel.Debug);
            outChar = mappedG0;
        }

        switch (ch)
        {
            case '\r':
                screenBuffer.CursorCol = 0;
                break;

            case '\n':
                screenBuffer.CursorRow++;
                if (screenBuffer.CursorRow >= screenBuffer.Rows)
                {
                    screenBuffer.ScrollUp();
                    screenBuffer.CursorRow = screenBuffer.Rows - 1;
                }
                break;

            default:
                screenBuffer.WriteChar(screenBuffer.CursorRow, screenBuffer.CursorCol, ch);
                screenBuffer.CursorCol++;
                if (screenBuffer.CursorCol >= screenBuffer.Cols)
                {
                    screenBuffer.CursorCol = 0;
                    screenBuffer.CursorRow++;
                    if (screenBuffer.CursorRow >= screenBuffer.Rows)
                    {
                        screenBuffer.ScrollUp();
                        screenBuffer.CursorRow = screenBuffer.Rows - 1;
                    }
                }
                break;
        }
    }

    private void HandleCSI(string csi)
    {
        char command = csi[^1];
        string paramString = csi.Length > 1 ? csi[..^1] : string.Empty;
        string[] parts = string.IsNullOrEmpty(paramString)
            ? Array.Empty<string>()
            : paramString.Split(';', StringSplitOptions.RemoveEmptyEntries)
                         .Select(p => p.TrimStart('>', '?')).ToArray();

        switch (command)
        {
            case 'H':
            case 'f':
                int row = parts.Length > 0 && int.TryParse(parts[0], out var r) ? r : 1;
                int col = parts.Length > 1 && int.TryParse(parts[1], out var c) ? c : 1;
                screenBuffer.SetCursorPosition(row - 1, col - 1);

                if (row == 22 && col == 1)
                    Logger.Log("[EMACS] Prompt aktiv – vänta på tangent", Logger.LogLevel.Info);
                break;
            case 'J':
                int mode = parts.Length > 0 && int.TryParse(parts[0], out var m) ? m : 0;
                screenBuffer.Clear(mode);
                break;
            case 'K':
                int modeK = parts.Length > 0 && int.TryParse(parts[0], out var mk) ? mk : 0;
                screenBuffer.ClearLine(modeK);
                break;
            case 'm':
                if (parts.Length == 0) { screenBuffer.ResetAttributes(); break; }
                foreach (var p in parts)
                    if (int.TryParse(p, out var code))
                        if (code == 0) screenBuffer.ResetAttributes();
                        else if (code == 7) screenBuffer.SetReverse(true);
                        else if (code == 27) screenBuffer.SetReverse(false);
                break;
        }
    }

    private Dictionary<string, Action> InitEsc0Commands()
    {
        return new Dictionary<string, Action>
    {
        // ────── Linjer och hörn (tecken + '!')
        { "#!", () => DrawGraphic('│') }, // vertikal linje
        { "$!", () => DrawGraphic('─') }, // horisontell linje
        { "%!", () => DrawGraphic('┌') }, // hörn uppe vänster
        { "&!", () => DrawGraphic('┐') }, // hörn uppe höger
        { "'!", () => DrawGraphic('└') }, // hörn nere vänster
        { "(!", () => DrawGraphic('┘') }, // hörn nere höger
        { ")!", () => DrawGraphic('├') }, // T‑korsning vänster
        { "*!", () => DrawGraphic('┤') }, // T‑korsning höger
        { "+!", () => DrawGraphic('┬') }, // T‑korsning upp
        { ",!", () => DrawGraphic('┴') }, // T‑korsning ner
        { "-!", () => DrawGraphic('┼') }, // korsning

        // ────── Statusfält / attribut
        { "6!", () => screenBuffer.SetCursorPosition(screenBuffer.Rows - 1, 0) }, // flytta till statusrad
        { "!!", () => { // rensa statusrad
            int lastRow = screenBuffer.Rows - 1;
            for (int c = 0; c < screenBuffer.Cols; c++)
                screenBuffer.WriteChar(lastRow, c, ' ');
        }},
        //{ "\"!", () => { /* Set status field attributes – kan implementeras */ } },

        // ────── Symboler (tecken + '!')
        { "A!", () => DrawGraphic('★') },
        { "B!", () => DrawGraphic('☆') },
        { "C!", () => DrawGraphic('●') },
        { "D!", () => DrawGraphic('○') },
        { "E!", () => DrawGraphic('◆') },
        { "F!", () => DrawGraphic('◇') },
        { "G!", () => DrawGraphic('▲') },
        { "H!", () => DrawGraphic('▼') },
        { "I!", () => DrawGraphic('►') },
        { "J!", () => DrawGraphic('◄') },
        { "\"!", () => {
            // Set status field attributes – i EMACS används den ofta före text på statusraden.
            // Vi kan välja att ignorera den visuellt, men det kan vara bra att nollställa ev. attribut.
            screenBuffer.ResetAttributes();
                        }},
        };
    }
    private Dictionary<string, Action<string>> InitEsc0HexCommands()
    {
        // Hex-koderna är de som skickas som två hextecken följt av '*'
        // Vi tar emot själva hexdelen som string (t.ex. "69") och kan använda den
        return new Dictionary<string, Action<string>>
        {
            { "69", _ => DrawGraphic('█') }, // full block
            { "6A", _ => DrawGraphic('▄') }, // lower half block
            { "6B", _ => DrawGraphic('▀') }, // upper half block
            { "6C", _ => DrawGraphic('▒') }, // medium shade
            { "6D", _ => DrawGraphic('░') }, // light shade
            { "6E", _ => DrawGraphic('▓') }, // dark shade
            // Här kan du fylla på fler hexkoder från PT200-manualen vid behov
        };
    }

    private Dictionary<byte, char> InitG1Map()
    {
        return new Dictionary<byte, char>
        {
            { 0x21, '│' }, { 0x22, '─' }, { 0x23, '┌' }, { 0x24, '┐' },
            { 0x25, '└' }, { 0x26, '┘' }, { 0x27, '├' }, { 0x28, '┤' },
            { 0x29, '┬' }, { 0x2A, '┴' }, { 0x2B, '┼' }, { 0x2C, '█' },
            { 0x2D, '▄' }, { 0x2E, '▀' }, { 0x2F, '▒' }, { 0x30, '░' },
            { 0x31, '▓' }, { 0x32, '▲' }, { 0x33, '▼' }, { 0x34, '►' },
            { 0x35, '◄' }, { 0x36, '★' }, { 0x37, '☆' }, { 0x38, '●' },
            { 0x39, '○' }, { 0x3A, '◆' }, { 0x3B, '◇' }
        };
    }

    private void DrawGraphic(char ch)
    {
        Logger.Log($"Put '{ch}' at ({screenBuffer.CursorRow},{screenBuffer.CursorCol})", Logger.LogLevel.Debug);
        screenBuffer.WriteChar(screenBuffer.CursorRow, screenBuffer.CursorCol, ch);
        screenBuffer.CursorCol++;
        if (screenBuffer.CursorCol >= screenBuffer.Cols)
        {
            screenBuffer.CursorCol = 0;
            AdvanceLine();
        }
    }

    internal void ParseDcsPayload(byte[] data)
    {
        Logger.LogHex(data, data.Length, "DCS Payload");
        Logger.Log($"[DCS] Payload-längd: {data.Length}", LogLevel.Info);
        if (data.Length == 0)
        {
            Logger.Log("[DCS] Tom payload – troligen initsekvens", Logger.LogLevel.Info);
            return;
        }

        string ascii = Encoding.ASCII.GetString(data);
        Logger.Log($"[DCS] ASCII: '{ascii}'", Logger.LogLevel.Info);

        if (ascii.StartsWith("$Q") || ascii.StartsWith("$G"))
        {
            EmacsMode = true;
            Logger.LogHex(data, data.Length, "Riktig $Q-payload");
            Logger.Log($"[EMACS] Layout tolkad – fält: {emacsLayout?.Fields.Count ?? 0}", Logger.LogLevel.Info);
            EmacsLayoutUpdated?.Invoke();
        }

        // Identifiera kommandon
        if (ascii.StartsWith("$Q"))
        {
            Logger.Log("[DCS] EMACS layout ($Q) tolkas", Logger.LogLevel.Info);
            emacsLayout = EmacsLayoutModel.Parse(data);
            EmacsMode = true;
        }
        else if (ascii.StartsWith("$G"))
        {
            Logger.Log("[DCS] Kommando: Set graphics mode ($G) – ignoreras", Logger.LogLevel.Warning);
            return;
        }
        else if (ascii.StartsWith("$B"))
        {
            Logger.Log("[DCS] Kommando: Load character set ($B) – ignoreras", Logger.LogLevel.Warning);
            return;
        }
        else if (ascii.StartsWith("$0"))
        {
            Logger.Log("[DCS] EMACS reset ($0) tolkas", Logger.LogLevel.Info);
            emacsLayout = null;
            EmacsMode = false;
            EmacsLayoutUpdated?.Invoke();
        }
        else
        {
            Logger.Log("[DCS] Okänt kommando – payload dump följer", Logger.LogLevel.Warning);
            Logger.LogHex(data, data.Length, "DCS Raw");
        }
    }

    private void ResetParserState()
    {
        state = ParseState.Normal;
        seqCharCount = 0;           // om du använder failsafe-räknaren
        csiBuffer.Clear();
        dcsBuffer.Clear();
        esc0Buffer.Clear();
        usingG1 = false;            // om du har G0/G1-växling
                                    // Återställ ev. andra parserflaggor här
    }

    private void ResetScreenState()
    {
        screenBuffer.Clear();       // rensa hela skärmen
        screenBuffer.SetCursorPosition(0, 0);
        screenBuffer.ResetAttributes();
        // Återställ ev. färger, scrollregioner, wrap-mode etc.
    }
}